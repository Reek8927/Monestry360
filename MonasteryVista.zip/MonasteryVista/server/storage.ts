import { type Monastery, type InsertMonastery } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  
  // Monastery methods
  getAllMonasteries(): Promise<Monastery[]>;
  getMonasteryById(id: string): Promise<Monastery | undefined>;
  searchMonasteries(query: string, region?: string, period?: string): Promise<Monastery[]>;
  createMonastery(monastery: InsertMonastery): Promise<Monastery>;
}

export class MemStorage implements IStorage {
  private users: Map<string, any>;
  private monasteries: Map<string, Monastery>;

  constructor() {
    this.users = new Map();
    this.monasteries = new Map();
    this.initializeMonasteries();
  }

  private initializeMonasteries() {
    const sampleMonasteries: InsertMonastery[] = [
      {
        name: "Rumtek Monastery",
        location: "East Sikkim • 24km from Gangtok",
        region: "east",
        established: "1740",
        historicalPeriod: "18th",
        description: "The largest monastery in Sikkim, Rumtek serves as the main seat of the Karma Kagyu lineage outside Tibet.",
        imageUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/rumtek-en.mp3", duration: 720 },
          hi: { url: "/audio/rumtek-hi.mp3", duration: 750 },
          ne: { url: "/audio/rumtek-ne.mp3", duration: 780 },
          bh: { url: "/audio/rumtek-bh.mp3", duration: 690 }
        },
        features: ["Main Prayer Hall", "Golden Stupa", "Monastery Museum", "Monks' Quarters"],
        virtualTourViews: [
          {
            name: "Main Prayer Hall",
            panoramicUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "The heart of the monastery with intricate Buddhist artwork"
          }
        ]
      },
      {
        name: "Pemayangtse Monastery",
        location: "West Sikkim • Pelling",
        region: "west",
        established: "1705",
        historicalPeriod: "18th",
        description: "One of the oldest and most important monasteries in Sikkim, housing precious manuscripts and artifacts.",
        imageUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/pemayangtse-en.mp3", duration: 900 },
          hi: { url: "/audio/pemayangtse-hi.mp3", duration: 920 },
          ne: { url: "/audio/pemayangtse-ne.mp3", duration: 950 },
          bh: { url: "/audio/pemayangtse-bh.mp3", duration: 880 }
        },
        features: ["Ancient Library", "Sacred Relics", "Traditional Architecture"],
        virtualTourViews: [
          {
            name: "Ancient Library",
            panoramicUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "Repository of ancient Buddhist texts and manuscripts"
          }
        ]
      },
      {
        name: "Tashiding Monastery",
        location: "West Sikkim • Sacred Hilltop",
        region: "west",
        established: "1717",
        historicalPeriod: "18th",
        description: "Considered the holiest monastery in Sikkim, positioned at the junction of Rathong and Rangeet rivers.",
        imageUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/tashiding-en.mp3", duration: 1080 },
          hi: { url: "/audio/tashiding-hi.mp3", duration: 1100 },
          ne: { url: "/audio/tashiding-ne.mp3", duration: 1150 },
          bh: { url: "/audio/tashiding-bh.mp3", duration: 1020 }
        },
        features: ["Sacred Stupa", "Hilltop Location", "River Junction"],
        virtualTourViews: [
          {
            name: "Sacred Stupa",
            panoramicUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "The sacred stupa with panoramic mountain views"
          }
        ]
      },
      {
        name: "Enchey Monastery",
        location: "East Sikkim • Gangtok",
        region: "east",
        established: "1840",
        historicalPeriod: "19th",
        description: "A serene monastery overlooking Gangtok, known for its peaceful ambiance and ancient murals.",
        imageUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/enchey-en.mp3", duration: 600 },
          hi: { url: "/audio/enchey-hi.mp3", duration: 620 },
          ne: { url: "/audio/enchey-ne.mp3", duration: 640 },
          bh: { url: "/audio/enchey-bh.mp3", duration: 580 }
        },
        features: ["Ancient Murals", "City Views", "Peaceful Gardens"],
        virtualTourViews: [
          {
            name: "Main Hall",
            panoramicUrl: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "Main prayer hall with ancient murals"
          }
        ]
      },
      {
        name: "Lingdum Monastery",
        location: "East Sikkim • Ranka",
        region: "east",
        established: "1999",
        historicalPeriod: "modern",
        description: "A modern monastery blending traditional and contemporary Buddhist architecture with stunning mountain views.",
        imageUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/lingdum-en.mp3", duration: 480 },
          hi: { url: "/audio/lingdum-hi.mp3", duration: 500 },
          ne: { url: "/audio/lingdum-ne.mp3", duration: 520 },
          bh: { url: "/audio/lingdum-bh.mp3", duration: 460 }
        },
        features: ["Modern Architecture", "Mountain Views", "Meditation Halls"],
        virtualTourViews: [
          {
            name: "Meditation Hall",
            panoramicUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "Modern meditation hall with traditional elements"
          }
        ]
      },
      {
        name: "Dubdi Monastery",
        location: "West Sikkim • Yuksom",
        region: "west",
        established: "1701",
        historicalPeriod: "18th",
        description: "The first monastery built in Sikkim, marking the beginning of Buddhism's formal establishment in the region.",
        imageUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        panoramicImageUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
        audioGuides: {
          en: { url: "/audio/dubdi-en.mp3", duration: 840 },
          hi: { url: "/audio/dubdi-hi.mp3", duration: 860 },
          ne: { url: "/audio/dubdi-ne.mp3", duration: 890 },
          bh: { url: "/audio/dubdi-bh.mp3", duration: 820 }
        },
        features: ["First Monastery", "Historical Significance", "Ancient Architecture"],
        virtualTourViews: [
          {
            name: "Historic Hall",
            panoramicUrl: "https://images.unsplash.com/photo-1582139329536-e7284fece509?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=960",
            description: "The original prayer hall where Buddhism was first established"
          }
        ]
      }
    ];

    sampleMonasteries.forEach(monastery => {
      const id = randomUUID();
      const fullMonastery: Monastery = { 
        ...monastery, 
        id,
        audioGuides: monastery.audioGuides || {},
        features: monastery.features || [],
        virtualTourViews: monastery.virtualTourViews || []
      };
      this.monasteries.set(id, fullMonastery);
    });
  }

  async getUser(id: string): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: any): Promise<any> {
    const id = randomUUID();
    const user: any = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllMonasteries(): Promise<Monastery[]> {
    return Array.from(this.monasteries.values());
  }

  async getMonasteryById(id: string): Promise<Monastery | undefined> {
    return this.monasteries.get(id);
  }

  async searchMonasteries(query: string, region?: string, period?: string): Promise<Monastery[]> {
    const monasteries = Array.from(this.monasteries.values());
    
    return monasteries.filter(monastery => {
      const matchesQuery = !query || 
        monastery.name.toLowerCase().includes(query.toLowerCase()) ||
        monastery.location.toLowerCase().includes(query.toLowerCase()) ||
        monastery.description.toLowerCase().includes(query.toLowerCase());
      
      const matchesRegion = !region || monastery.region === region;
      const matchesPeriod = !period || monastery.historicalPeriod === period;
      
      return matchesQuery && matchesRegion && matchesPeriod;
    });
  }

  async createMonastery(insertMonastery: InsertMonastery): Promise<Monastery> {
    const id = randomUUID();
    const monastery: Monastery = { 
      ...insertMonastery, 
      id,
      audioGuides: insertMonastery.audioGuides || {},
      features: insertMonastery.features || [],
      virtualTourViews: insertMonastery.virtualTourViews || []
    };
    this.monasteries.set(id, monastery);
    return monastery;
  }
}

export const storage = new MemStorage();
