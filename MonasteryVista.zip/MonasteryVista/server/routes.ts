import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMonasterySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all monasteries
  app.get("/api/monasteries", async (req, res) => {
    try {
      const monasteries = await storage.getAllMonasteries();
      res.json(monasteries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monasteries" });
    }
  });

  // Search monasteries - must come before :id route
  app.get("/api/monasteries/search", async (req, res) => {
    try {
      const { q: query, region, period } = req.query;
      
      const monasteries = await storage.searchMonasteries(
        query as string || "",
        region as string,
        period as string
      );
      
      res.json(monasteries);
    } catch (error) {
      res.status(500).json({ message: "Failed to search monasteries" });
    }
  });

  // Get monastery by ID
  app.get("/api/monasteries/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const monastery = await storage.getMonasteryById(id);
      
      if (!monastery) {
        return res.status(404).json({ message: "Monastery not found" });
      }
      
      res.json(monastery);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monastery" });
    }
  });

  // Create new monastery (for admin purposes)
  app.post("/api/monasteries", async (req, res) => {
    try {
      const validatedData = insertMonasterySchema.parse(req.body);
      const monastery = await storage.createMonastery(validatedData);
      res.status(201).json(monastery);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create monastery" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
