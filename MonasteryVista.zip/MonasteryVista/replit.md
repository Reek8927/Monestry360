# Overview

Monastery360 is a full-stack web application for exploring Buddhist monasteries in Sikkim through virtual tours, audio guides, and interactive features. The application provides immersive 360° panoramic views, multilingual audio narration, and comprehensive monastery information including historical details, features, and cultural significance.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for type safety and modern development
- **Vite** as the build tool for fast development and optimized production builds
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management and caching
- **shadcn/ui** component library built on Radix UI primitives for consistent, accessible UI components
- **Tailwind CSS** for utility-first styling with custom heritage-themed color palette
- **Three.js** for 360° panoramic viewing experiences

## Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **RESTful API** design with endpoints for monastery data retrieval and search
- **In-memory storage** with sample data initialization (designed to be replaced with database)
- **Middleware** for request logging and error handling
- **Static file serving** for production builds

## Data Layer
- **Drizzle ORM** configured for PostgreSQL with type-safe database operations
- **Neon Database** serverless PostgreSQL integration
- **Zod schemas** for runtime validation and type inference
- **JSON storage** for complex data structures (audio guides, features, virtual tour views)

## Authentication & Session Management
- **Session-based authentication** infrastructure prepared
- **PostgreSQL session storage** using connect-pg-simple

## Styling & Design System
- **Heritage-themed design** with saffron, red, and gold color palette reflecting Buddhist aesthetics
- **Responsive design** with mobile-first approach
- **Inter font** for body text and Playfair Display for headings
- **CSS custom properties** for consistent theming across light/dark modes

## Development Features
- **Hot module replacement** in development
- **TypeScript path mapping** for clean imports
- **ESLint and Prettier** configuration for code quality
- **Replit integration** with development banner and cartographer plugin

# External Dependencies

## Database & Storage
- **Neon Database** - Serverless PostgreSQL hosting
- **Drizzle Kit** - Database schema management and migrations

## UI & Styling
- **Radix UI** - Accessible component primitives for dialogs, dropdowns, forms
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library for consistent iconography
- **Three.js** - 3D graphics library for panoramic viewing

## Frontend Libraries
- **React Hook Form** with Hookform Resolvers for form validation
- **TanStack React Query** - Server state management
- **Embla Carousel** - Touch-friendly carousel component
- **Date-fns** - Date manipulation utilities

## Development Tools
- **Vite** - Frontend build tool with React plugin
- **TypeScript** - Static type checking
- **ESBuild** - Fast JavaScript bundler for production
- **TSX** - TypeScript execution for development server

## Replit Integration
- **@replit/vite-plugin-cartographer** - Development tooling
- **@replit/vite-plugin-runtime-error-modal** - Enhanced error handling

## Audio & Media
- Custom audio player implementation for multilingual monastery narrations supporting English, Hindi, Nepali, and Bhutia languages

## External APIs
- **Unsplash** - Placeholder monastery images (to be replaced with actual monastery photography)