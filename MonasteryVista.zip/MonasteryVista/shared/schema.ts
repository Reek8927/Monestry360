import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const monasteries = pgTable("monasteries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  location: text("location").notNull(),
  region: text("region").notNull(), // east, west, north, south
  established: text("established").notNull(), // year or period
  description: text("description").notNull(),
  historicalPeriod: text("historical_period").notNull(), // 17th, 18th, 19th, modern
  imageUrl: text("image_url").notNull(),
  panoramicImageUrl: text("panoramic_image_url").notNull(),
  audioGuides: jsonb("audio_guides").$type<{
    [language: string]: {
      url: string;
      duration: number; // in seconds
    }
  }>().notNull().default({}),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  virtualTourViews: jsonb("virtual_tour_views").$type<{
    name: string;
    panoramicUrl: string;
    description: string;
  }[]>().notNull().default([]),
});

export const insertMonasterySchema = createInsertSchema(monasteries).omit({
  id: true,
});

export type InsertMonastery = z.infer<typeof insertMonasterySchema>;
export type Monastery = typeof monasteries.$inferSelect;
