import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, FileBox, Play, MapPin, Calendar, Info } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { Header } from "@/components/header";
import { PanoramicViewer } from "@/components/panoramic-viewer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { type Monastery } from "@shared/schema";

export default function MonasteryDetail() {
  const { id } = useParams<{ id: string }>();
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [isPanoramicViewerOpen, setIsPanoramicViewerOpen] = useState(false);

  const { data: monastery, isLoading, error } = useQuery<Monastery>({
    queryKey: ["/api/monasteries", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-4xl mx-auto space-y-8">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-64 w-full rounded-xl" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-32 w-full" />
              </div>
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-20 w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !monastery) {
    return (
      <div className="min-h-screen bg-background">
        <Header currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-2xl font-serif font-bold text-foreground mb-4">
              Monastery Not Found
            </h1>
            <p className="text-muted-foreground mb-8">
              The monastery you're looking for could not be found.
            </p>
            <Link href="/">
              <Button>Return Home</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const audioGuide = monastery.audioGuides[currentLanguage];

  return (
    <div className="min-h-screen bg-background">
      <Header currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Back Navigation */}
          <Link href="/">
            <Button variant="ghost" className="mb-6" data-testid="button-back">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Monasteries
            </Button>
          </Link>

          {/* Hero Image and Title */}
          <div className="relative mb-8">
            <div className="aspect-video w-full rounded-xl overflow-hidden">
              <img
                src={monastery.imageUrl}
                alt={monastery.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute top-4 right-4">
              <Button
                size="lg"
                className="bg-heritage-saffron hover:bg-heritage-saffron/90 text-primary-foreground"
                onClick={() => setIsPanoramicViewerOpen(true)}
                data-testid="button-virtual-tour"
              >
                <FileBox className="mr-2 h-5 w-5" />
                360° Virtual Tour
              </Button>
            </div>
          </div>

          {/* Monastery Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground">
                  {monastery.name}
                </h1>
                <Badge className="bg-heritage-saffron text-primary-foreground">
                  {monastery.established}
                </Badge>
              </div>

              <div className="flex items-center text-muted-foreground mb-4">
                <MapPin className="mr-2 h-4 w-4" />
                {monastery.location}
              </div>

              <div className="flex items-center text-muted-foreground mb-6">
                <Calendar className="mr-2 h-4 w-4" />
                {monastery.historicalPeriod} Century
              </div>

              <p className="text-foreground leading-relaxed mb-6">
                {monastery.description}
              </p>

              {audioGuide && (
                <Button
                  variant="outline"
                  className="border-heritage-saffron text-heritage-saffron hover:bg-heritage-saffron hover:text-primary-foreground"
                  data-testid="button-audio-guide"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Play Audio Guide ({Math.floor(audioGuide.duration / 60)} min)
                </Button>
              )}
            </div>

            <div className="space-y-6">
              {/* Features */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Info className="mr-2 h-5 w-5" />
                    Key Features
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-2">
                    {monastery.features.map((feature: string, index: number) => (
                      <div
                        key={index}
                        className="flex items-center p-2 bg-muted rounded-lg"
                      >
                        <span className="w-2 h-2 bg-heritage-saffron rounded-full mr-3" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Virtual Tour Views */}
              {monastery.virtualTourViews.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Virtual Tour Views</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {monastery.virtualTourViews.map((view: any, index: number) => (
                        <div
                          key={index}
                          className="p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                          onClick={() => setIsPanoramicViewerOpen(true)}
                        >
                          <h4 className="font-medium text-foreground">{view.name}</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {view.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Panoramic Viewer */}
      <PanoramicViewer
        monastery={monastery}
        isOpen={isPanoramicViewerOpen}
        currentLanguage={currentLanguage}
        onClose={() => setIsPanoramicViewerOpen(false)}
        onLanguageChange={setCurrentLanguage}
      />
    </div>
  );
}
