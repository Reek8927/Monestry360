import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileBox, ArrowRight } from "lucide-react";
import { Header } from "@/components/header";
import { SearchFilter } from "@/components/search-filter";
import { MonasteryCard } from "@/components/monastery-card";
import { PanoramicViewer } from "@/components/panoramic-viewer";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { type Monastery } from "@shared/schema";

export default function Home() {
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("");
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [selectedMonastery, setSelectedMonastery] = useState<Monastery | null>(null);
  const [isPanoramicViewerOpen, setIsPanoramicViewerOpen] = useState(false);
  const [audioPlayingMonastery, setAudioPlayingMonastery] = useState<Monastery | null>(null);
  const { toast } = useToast();

  // Fetch monasteries based on search/filter criteria
  const { data: monasteries = [], isLoading } = useQuery({
    queryKey: ["/api/monasteries/search", searchQuery, selectedRegion, selectedPeriod],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("q", searchQuery);
      if (selectedRegion) params.append("region", selectedRegion);
      if (selectedPeriod) params.append("period", selectedPeriod);
      
      const response = await fetch(`/api/monasteries/search?${params}`);
      if (!response.ok) throw new Error("Failed to fetch monasteries");
      return response.json();
    },
  });

  const handleSearch = useCallback((query: string, region: string, period: string) => {
    setSearchQuery(query);
    setSelectedRegion(region);
    setSelectedPeriod(period);
  }, []);

  const handleOpenVirtualTour = (monastery: Monastery) => {
    setSelectedMonastery(monastery);
    setIsPanoramicViewerOpen(true);
  };

  const handlePlayNarration = (monastery: Monastery) => {
    const audioGuide = monastery.audioGuides[currentLanguage];
    if (!audioGuide) {
      toast({
        title: "Audio Not Available",
        description: `Audio guide in ${currentLanguage} is not available for this monastery.`,
        variant: "destructive",
      });
      return;
    }
    
    setAudioPlayingMonastery(monastery);
    setSelectedMonastery(monastery);
    setIsPanoramicViewerOpen(true);
  };

  const handleStartVirtualTour = () => {
    if (monasteries.length > 0) {
      handleOpenVirtualTour(monasteries[0]);
    }
  };

  const handleExploreMonasteries = () => {
    const exploreSection = document.getElementById("explore");
    exploreSection?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden monastery-pattern">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          }}
        />
        
        <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-6 leading-tight">
              Discover Sikkim's{" "}
              <span className="text-heritage-saffron">Sacred Heritage</span>
            </h2>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Immerse yourself in the spiritual legacy of over 200 monasteries through interactive 360° virtual tours and multilingual narrated experiences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-heritage-saffron hover:bg-heritage-saffron/90 text-primary-foreground"
                onClick={handleStartVirtualTour}
                data-testid="button-start-virtual-tour"
              >
                <FileBox className="mr-2 h-5 w-5" />
                Start Virtual Tour
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-heritage-saffron text-heritage-saffron hover:bg-heritage-saffron hover:text-primary-foreground"
                onClick={handleExploreMonasteries}
                data-testid="button-explore-monasteries"
              >
                <span className="mr-2">📍</span>
                Explore Monasteries
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <SearchFilter onSearch={handleSearch} />

      {/* Monastery Grid */}
      <section className="py-16" id="explore">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
              Sacred Monasteries of Sikkim
            </h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Each monastery tells a unique story of spiritual devotion, architectural mastery, and cultural preservation spanning centuries.
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, index) => (
                <div key={index} className="space-y-4">
                  <Skeleton className="h-48 w-full rounded-xl" />
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ))}
            </div>
          ) : monasteries.length === 0 ? (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🏔️</div>
              <h4 className="text-xl font-serif font-semibold text-foreground mb-2">
                No monasteries found
              </h4>
              <p className="text-muted-foreground">
                Try adjusting your search criteria or explore all monasteries.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {monasteries.map((monastery: Monastery) => (
                <MonasteryCard
                  key={monastery.id}
                  monastery={monastery}
                  currentLanguage={currentLanguage}
                  onOpenVirtualTour={handleOpenVirtualTour}
                  onPlayNarration={handlePlayNarration}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Research Section */}
      <section className="py-16 bg-muted" id="research">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6">
              Digital Preservation Initiative
            </h3>
            <p className="text-lg text-muted-foreground mb-12">
              Our collaborative effort with monasteries and scholars to preserve and share Sikkim's invaluable cultural heritage for future generations.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-card rounded-xl p-6 border border-border">
                <div className="w-12 h-12 bg-heritage-saffron rounded-lg flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary-foreground text-xl">📜</span>
                </div>
                <h4 className="font-serif font-semibold text-card-foreground mb-2">Ancient Manuscripts</h4>
                <p className="text-sm text-muted-foreground">Digital preservation of rare Buddhist texts and historical documents.</p>
              </div>
              
              <div className="bg-card rounded-xl p-6 border border-border">
                <div className="w-12 h-12 bg-heritage-red rounded-lg flex items-center justify-center mx-auto mb-4">
                  <span className="text-secondary-foreground text-xl">🎨</span>
                </div>
                <h4 className="font-serif font-semibold text-card-foreground mb-2">Sacred Murals</h4>
                <p className="text-sm text-muted-foreground">High-resolution documentation of intricate wall paintings and artwork.</p>
              </div>
              
              <div className="bg-card rounded-xl p-6 border border-border">
                <div className="w-12 h-12 bg-heritage-gold rounded-lg flex items-center justify-center mx-auto mb-4">
                  <span className="text-accent-foreground text-xl">🎙️</span>
                </div>
                <h4 className="font-serif font-semibold text-card-foreground mb-2">Oral Traditions</h4>
                <p className="text-sm text-muted-foreground">Recording and preserving stories from monks and local communities.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-heritage-saffron to-heritage-red rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">☸</span>
                </div>
                <h4 className="text-xl font-serif font-bold">Monastery360</h4>
              </div>
              <p className="text-gray-300 mb-4 max-w-md">
                Preserving and sharing the sacred heritage of Sikkim's monasteries through immersive digital experiences.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">📘</a>
                <a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">🐦</a>
                <a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">📷</a>
              </div>
            </div>
            
            <div>
              <h5 className="font-semibold text-background mb-4">Explore</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">All Monasteries</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Virtual Tours</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Audio Guides</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Research Portal</a></li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold text-background mb-4">Support</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">About Project</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Contribute</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-heritage-saffron transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-300 text-sm">
              © 2024 Monastery360. Built with respect for Sikkim's sacred heritage.
            </p>
          </div>
        </div>
      </footer>

      {/* Panoramic Viewer Modal */}
      <PanoramicViewer
        monastery={selectedMonastery}
        isOpen={isPanoramicViewerOpen}
        currentLanguage={currentLanguage}
        onClose={() => {
          setIsPanoramicViewerOpen(false);
          setSelectedMonastery(null);
          setAudioPlayingMonastery(null);
        }}
        onLanguageChange={setCurrentLanguage}
      />
    </div>
  );
}
