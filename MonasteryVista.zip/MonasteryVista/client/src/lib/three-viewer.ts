import * as THREE from 'three';

export class PanoramicViewer {
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private sphere: THREE.Mesh;
  private isUserInteracting = false;
  private onPointerDownPointerX = 0;
  private onPointerDownPointerY = 0;
  private onPointerDownLon = 0;
  private onPointerDownLat = 0;
  private phi = 0;
  private theta = 0;
  private lon = 0;
  private lat = 0;

  constructor(container: HTMLElement) {
    // Scene setup
    this.scene = new THREE.Scene();
    
    // Camera setup
    this.camera = new THREE.PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      1,
      1100
    );
    
    // Renderer setup
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(this.renderer.domElement);
    
    // Create sphere geometry for 360° view
    const geometry = new THREE.SphereGeometry(500, 60, 40);
    geometry.scale(-1, 1, 1); // Invert to see texture from inside
    
    // Create material (texture will be added later)
    const material = new THREE.MeshBasicMaterial();
    this.sphere = new THREE.Mesh(geometry, material);
    this.scene.add(this.sphere);
    
    // Event listeners
    this.setupEventListeners(container);
    
    // Start render loop
    this.animate();
  }

  private setupEventListeners(container: HTMLElement) {
    const onPointerDown = (event: PointerEvent) => {
      if (event.isPrimary === false) return;
      
      this.isUserInteracting = true;
      this.onPointerDownPointerX = event.clientX;
      this.onPointerDownPointerY = event.clientY;
      this.onPointerDownLon = this.lon;
      this.onPointerDownLat = this.lat;
      
      container.style.cursor = 'grabbing';
    };

    const onPointerMove = (event: PointerEvent) => {
      if (event.isPrimary === false) return;
      
      if (this.isUserInteracting === true) {
        this.lon = (this.onPointerDownPointerX - event.clientX) * 0.1 + this.onPointerDownLon;
        this.lat = (event.clientY - this.onPointerDownPointerY) * 0.1 + this.onPointerDownLat;
      }
    };

    const onPointerUp = (event: PointerEvent) => {
      if (event.isPrimary === false) return;
      
      this.isUserInteracting = false;
      container.style.cursor = 'grab';
    };

    const onWheel = (event: WheelEvent) => {
      const fov = this.camera.fov + event.deltaY * 0.05;
      this.camera.fov = THREE.MathUtils.clamp(fov, 10, 75);
      this.camera.updateProjectionMatrix();
    };

    container.addEventListener('pointerdown', onPointerDown);
    container.addEventListener('pointermove', onPointerMove);
    container.addEventListener('pointerup', onPointerUp);
    container.addEventListener('wheel', onWheel);
    container.style.cursor = 'grab';
  }

  public loadTexture(imageUrl: string) {
    const loader = new THREE.TextureLoader();
    loader.load(
      imageUrl,
      (texture: THREE.Texture) => {
        (this.sphere.material as THREE.MeshBasicMaterial).map = texture;
        (this.sphere.material as THREE.MeshBasicMaterial).needsUpdate = true;
      },
      undefined,
      (error: unknown) => {
        console.error('Error loading panoramic texture:', error);
      }
    );
  }

  public resetView() {
    this.lon = 0;
    this.lat = 0;
    this.camera.fov = 75;
    this.camera.updateProjectionMatrix();
  }

  public dispose() {
    this.renderer.dispose();
    this.sphere.geometry.dispose();
    (this.sphere.material as THREE.MeshBasicMaterial).dispose();
  }

  private animate = () => {
    requestAnimationFrame(this.animate);
    this.update();
  };

  private update() {
    if (this.isUserInteracting === false) {
      this.lon += 0.1;
    }

    this.lat = Math.max(-85, Math.min(85, this.lat));
    this.phi = THREE.MathUtils.degToRad(90 - this.lat);
    this.theta = THREE.MathUtils.degToRad(this.lon);

    const x = 500 * Math.sin(this.phi) * Math.cos(this.theta);
    const y = 500 * Math.cos(this.phi);
    const z = 500 * Math.sin(this.phi) * Math.sin(this.theta);

    this.camera.lookAt(x, y, z);
    this.renderer.render(this.scene, this.camera);
  }

  public resize() {
    const container = this.renderer.domElement.parentElement;
    if (!container) return;

    this.camera.aspect = container.clientWidth / container.clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(container.clientWidth, container.clientHeight);
  }
}
