import { useEffect, useRef, useState } from "react";
import { X, RotateCcw, Maximize, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AudioPlayer } from "./audio-player";
import { type Monastery } from "@shared/schema";
import { PanoramicViewer as ThreeViewer } from "@/lib/three-viewer";

interface PanoramicViewerProps {
  monastery: Monastery | null;
  isOpen: boolean;
  currentLanguage: string;
  onClose: () => void;
  onLanguageChange: (language: string) => void;
}

export function PanoramicViewer({
  monastery,
  isOpen,
  currentLanguage,
  onClose,
  onLanguageChange,
}: PanoramicViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const viewerRef = useRef<ThreeViewer | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showInfo, setShowInfo] = useState(true);

  useEffect(() => {
    if (!isOpen || !monastery || !containerRef.current) return;

    setIsLoading(true);

    // Initialize Three.js viewer
    const viewer = new ThreeViewer(containerRef.current);
    viewerRef.current = viewer;

    // Load panoramic image
    viewer.loadTexture(monastery.panoramicImageUrl);
    
    // Simulate loading time for better UX
    setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    // Handle resize
    const handleResize = () => {
      viewer.resize();
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      viewer.dispose();
      viewerRef.current = null;
    };
  }, [isOpen, monastery]);

  const handleResetView = () => {
    viewerRef.current?.resetView();
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  if (!isOpen || !monastery) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/95" data-testid="panoramic-viewer">
      <div className="panoramic-viewer w-full h-full relative">
        {/* Three.js Container */}
        <div ref={containerRef} className="w-full h-full" />

        {/* Loading State */}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center text-white">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-heritage-saffron border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-lg">Loading 360° Experience...</p>
              <p className="text-sm text-gray-400 mt-2">{monastery.name}</p>
            </div>
          </div>
        )}

        {/* Audio Controls */}
        {!isLoading && (
          <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
            <AudioPlayer
              monastery={monastery}
              currentLanguage={currentLanguage}
              onLanguageChange={onLanguageChange}
              onClose={onClose}
            />
          </div>
        )}

        {/* Navigation Controls */}
        {!isLoading && (
          <div className="absolute top-6 left-6 space-y-2">
            <Button
              variant="secondary"
              size="icon"
              onClick={handleResetView}
              className="floating-controls shadow-lg"
              data-testid="button-reset-view"
            >
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={toggleFullscreen}
              className="floating-controls shadow-lg"
              data-testid="button-fullscreen"
            >
              <Maximize className="h-4 w-4" />
            </Button>
            <Button
              variant="secondary"
              size="icon"
              onClick={() => setShowInfo(!showInfo)}
              className="floating-controls shadow-lg"
              data-testid="button-toggle-info"
            >
              <Info className="h-4 w-4" />
            </Button>
          </div>
        )}

        {/* Close Button */}
        <Button
          variant="secondary"
          size="icon"
          onClick={onClose}
          className="absolute top-6 right-6 floating-controls shadow-lg hover:text-heritage-red"
          data-testid="button-close-viewer"
        >
          <X className="h-5 w-5" />
        </Button>

        {/* Info Panel */}
        {!isLoading && showInfo && (
          <div className="floating-controls absolute top-6 left-1/2 transform -translate-x-1/2 rounded-xl border border-border p-4 shadow-lg max-w-md">
            <h4 className="font-serif font-semibold text-foreground mb-1">
              {monastery.name}
            </h4>
            <p className="text-sm text-muted-foreground">
              Main Prayer Hall - 360° View
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
