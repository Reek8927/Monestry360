import { useState } from "react";
import { Play, FileBox, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type Monastery } from "@shared/schema";

interface MonasteryCardProps {
  monastery: Monastery;
  currentLanguage: string;
  onOpenVirtualTour: (monastery: Monastery) => void;
  onPlayNarration: (monastery: Monastery) => void;
}

export function MonasteryCard({
  monastery,
  currentLanguage,
  onOpenVirtualTour,
  onPlayNarration,
}: MonasteryCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);

  const getPeriodBadgeColor = (period: string) => {
    switch (period) {
      case "17th":
      case "18th":
        return "bg-heritage-saffron text-primary-foreground";
      case "19th":
        return "bg-heritage-red text-secondary-foreground";
      default:
        return "bg-heritage-gold text-accent-foreground";
    }
  };

  const audioGuide = monastery.audioGuides[currentLanguage];
  const duration = audioGuide ? `${Math.floor(audioGuide.duration / 60)} min` : "N/A";

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300" data-testid={`card-monastery-${monastery.id}`}>
      <div className="relative h-48 overflow-hidden">
        {!imageLoaded && (
          <div className="absolute inset-0 bg-muted animate-pulse" />
        )}
        <img
          src={monastery.imageUrl}
          alt={monastery.name}
          className={`w-full h-full object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageLoaded(true)}
        />
        <div className="absolute top-2 left-2">
          <Badge className={getPeriodBadgeColor(monastery.historicalPeriod)}>
            {monastery.established}
          </Badge>
        </div>
        <div className="absolute top-2 right-2">
          <Button
            size="icon"
            className="bg-white/90 hover:bg-white text-heritage-saffron rounded-full"
            onClick={() => onOpenVirtualTour(monastery)}
            data-testid={`button-virtual-tour-${monastery.id}`}
          >
            <FileBox className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <CardContent className="p-6">
        <h4 className="text-xl font-serif font-semibold text-card-foreground mb-2">
          {monastery.name}
        </h4>
        <p className="text-muted-foreground text-sm mb-3">
          {monastery.location}
        </p>
        <p className="text-card-foreground mb-4 text-sm leading-relaxed">
          {monastery.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="sm"
              className="text-heritage-saffron hover:text-heritage-red p-0"
              onClick={() => onPlayNarration(monastery)}
              disabled={!audioGuide}
              data-testid={`button-audio-${monastery.id}`}
            >
              <Play className="h-4 w-4 mr-1" />
              <span className="text-xs">Audio Guide</span>
            </Button>
            <span className="text-xs text-muted-foreground">{duration}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-heritage-saffron hover:text-heritage-red p-0"
            data-testid={`button-learn-more-${monastery.id}`}
          >
            <span className="text-sm font-medium mr-1">Learn More</span>
            <ArrowRight className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

