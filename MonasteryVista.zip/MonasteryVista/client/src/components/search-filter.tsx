import { useState, useEffect } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface SearchFilterProps {
  onSearch: (query: string, region: string, period: string) => void;
}

export function SearchFilter({ onSearch }: SearchFilterProps) {
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState("all");
  const [period, setPeriod] = useState("all");

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      onSearch(query, region === "all" ? "" : region, period === "all" ? "" : period);
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [query, region, period, onSearch]);

  const regions = [
    { value: "all", label: "All Regions" },
    { value: "east", label: "East Sikkim" },
    { value: "west", label: "West Sikkim" },
    { value: "north", label: "North Sikkim" },
    { value: "south", label: "South Sikkim" },
  ];

  const periods = [
    { value: "all", label: "All Periods" },
    { value: "17th", label: "17th Century" },
    { value: "18th", label: "18th Century" },
    { value: "19th", label: "19th Century" },
    { value: "modern", label: "Modern" },
  ];

  return (
    <section className="py-16 bg-muted">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card rounded-xl shadow-lg p-6 border border-border">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    type="text"
                    placeholder="Search monasteries by name, location, or period..."
                    className="pl-10"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    data-testid="input-search"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={period} onValueChange={setPeriod}>
                  <SelectTrigger className="min-w-[120px]" data-testid="select-period">
                    <SelectValue placeholder="All Periods" />
                  </SelectTrigger>
                  <SelectContent>
                    {periods.map((p) => (
                      <SelectItem key={p.value} value={p.value}>
                        {p.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={region} onValueChange={setRegion}>
                  <SelectTrigger className="min-w-[120px]" data-testid="select-region">
                    <SelectValue placeholder="All Regions" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((r) => (
                      <SelectItem key={r.value} value={r.value}>
                        {r.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
